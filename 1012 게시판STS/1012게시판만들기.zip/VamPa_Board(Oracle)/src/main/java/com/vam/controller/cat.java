package com.vam.controller;
import lombok.Data;

@Data
public class cat {
	private String name;
	private int 이름;
	private double weight;
	private double height;
	// cat클래스를 만들어 변수를 넣고 클래스 위에 @Data
	// 프로젝트익스플로어에서 해앋 클래스 들어가서 겟셋이 만들어졌는지 확인
}
