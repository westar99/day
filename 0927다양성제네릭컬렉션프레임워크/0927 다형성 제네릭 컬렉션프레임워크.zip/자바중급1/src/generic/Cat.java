package generic;

/**
 * 
 * @author 배성원
 * @param 파라미터 없음
 * @apiNote 고양이 객체
 *
 */
public class Cat {
	int age;
	double weight;
	double height;
	
	public void cry() {
		 System.out.println("야오옹");
	}
}
