package 자바중급1;

public class 호랑이 extends 동물{

}
