package 자바중급1;

public class 독수리 extends 동물{

}
