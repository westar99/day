package 자바중급1;

public class 코끼리 extends 동물{

}
