package 자바중급1;

public interface 애완동물 {
	public void 주인을따르다();
}
