package 자바중급1;

public class 동물 {
	int age;
	double weight;
	double height;
}
