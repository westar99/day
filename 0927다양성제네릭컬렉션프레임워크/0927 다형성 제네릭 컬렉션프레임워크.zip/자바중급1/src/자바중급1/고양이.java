package 자바중급1;

public class 고양이 extends 동물 implements 애완동물{

	@Override
	public void 주인을따르다() {
		System.out.println("고양이는 주인을 따릅니다.");
		
	}
	
}
