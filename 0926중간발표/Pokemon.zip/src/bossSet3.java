
public class bossSet3 extends pokemon{
	
	public bossSet3(String name,int maxHp,int attack, int defence, String type){
		super(name);

		super.maxHp = maxHp;
		super.presentHp = maxHp;
	
		super.attack = attack;
		
		super.defence = defence;
		super.presentDefence = defence;
		
		super.type = type;
	} 
}
